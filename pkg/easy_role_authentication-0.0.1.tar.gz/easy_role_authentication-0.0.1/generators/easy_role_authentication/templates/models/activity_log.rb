class ActivityLog < ActiveRecord::Base
end
