class Right < ActiveRecord::Base
end
