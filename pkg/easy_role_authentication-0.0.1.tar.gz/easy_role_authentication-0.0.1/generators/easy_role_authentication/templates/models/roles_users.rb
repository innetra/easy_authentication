class RolesUsers < ActiveRecord::Base
end
