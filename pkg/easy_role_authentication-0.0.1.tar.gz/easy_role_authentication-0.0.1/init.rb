require File.dirname(__FILE__) + '/lib/easy_role_authentication'
require File.dirname(__FILE__) + '/lib/by_password'
require File.dirname(__FILE__) + '/lib/by_cookie_token'
require File.dirname(__FILE__) + '/lib/user'
